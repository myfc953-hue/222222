package com.yuki.gnssmonitor;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.GnssStatus;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends android.app.Activity {

    private static final long REFRESH_MS = 500L;   // 0.5 秒刷新一次
    private static final int REQ_CODE = 1001;

    private TextView tvLat, tvLon, tvSpeed, tvSpeedUnit, tvSatCount, tvSatDetail, tvStatus;

    private LocationManager locationManager;
    private GnssStatus.Callback gnssCallback;
    private LocationListener locationListener;

    // 卫星数（GNSS 回调）
    private volatile int satVisible = 0;
    private volatile int satUsed = 0;

    // 位置与速度
    private volatile Location lastLocation;
    private volatile Location prevLocation;
    private volatile double lastSpeedMps = 0.0;
    private volatile double lastBearing = 0.0;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private boolean started = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);

        tvLat = findViewById(R.id.tvLat);
        tvLon = findViewById(R.id.tvLon);
        tvSpeed = findViewById(R.id.tvSpeed);
        tvSpeedUnit = findViewById(R.id.tvSpeedUnit);
        tvSatCount = findViewById(R.id.tvSatCount);
        tvSatDetail = findViewById(R.id.tvSatDetail);
        tvStatus = findViewById(R.id.tvStatus);

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        // 每 0.5 秒把最新数据刷到界面上
        ui.post(renderTask);

        if (hasLocationPermission()) {
            startLocation();
        } else {
            tvStatus.setText("正在申请定位权限…");
            requestPermissions(new String[]{
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
            }, REQ_CODE);
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_CODE) {
            if (hasLocationPermission()) {
                startLocation();
            } else {
                tvStatus.setText("未获得定位权限，无法读取卫星数据。请在系统设置中允许定位。");
            }
        }
    }

    @SuppressLint("MissingPermission")
    private void startLocation() {
        if (started) return;
        started = true;
        tvStatus.setText("正在搜索卫星…");

        // ---------- 位置 / 速度 ----------
        locationListener = new LocationListener() {
            @Override
            public void onLocationChanged(Location location) {
                if (location == null) return;
                // 记录上一个点，用于速度回退推算
                Location old = lastLocation;
                if (old != null && old != location) {
                    prevLocation = old;
                }
                lastLocation = location;

                float sp = location.getSpeed();
                if (!location.hasSpeed()) {
                    sp = computeSpeedFromPositions(prevLocation, location);
                }
                if (Float.isNaN(sp) || sp < 0f) sp = 0f;
                lastSpeedMps = sp;
                if (location.hasBearing()) lastBearing = location.getBearing();
            }

            @Override
            public void onProviderEnabled(String provider) { }

            @Override
            public void onProviderDisabled(String provider) { }
        };

        try {
            locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER, REFRESH_MS, 0f, locationListener, Looper.getMainLooper());
        } catch (Exception ignored) { }
        try {
            locationManager.requestLocationUpdates(
                    LocationManager.NETWORK_PROVIDER, REFRESH_MS, 0f, locationListener, Looper.getMainLooper());
        } catch (Exception ignored) { }
        // 被动源做兜底
        try {
            locationManager.requestLocationUpdates(
                    LocationManager.PASSIVE_PROVIDER, REFRESH_MS, 0f, locationListener, Looper.getMainLooper());
        } catch (Exception ignored) { }

        registerGnss();
    }

    /** 没有硬件速度时，用两次定位的位置差估算速度 */
    private float computeSpeedFromPositions(Location a, Location b) {
        if (a == null || b == null) return 0f;
        long dt = b.getTime() - a.getTime();
        if (dt <= 0) return 0f;
        float meters = a.distanceTo(b);
        return (float) (meters / (dt / 1000.0));
    }

    // ---------- 卫星星数 ----------
    private void registerGnss() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                gnssCallback = new GnssStatus.Callback() {
                    @Override
                    public void onSatelliteStatusChanged(GnssStatus status) {
                        int visible = status.getSatelliteCount();
                        int used = 0;
                        for (int i = 0; i < visible; i++) {
                            if (status.usedInFix(i)) used++;
                        }
                        satVisible = visible;
                        satUsed = used;
                    }

                    @Override
                    public void onStarted() { }
                    @Override
                    public void onStopped() { }
                };
                locationManager.registerGnssStatusCallback(gnssCallback, new Handler(Looper.getMainLooper()));
            } else {
                locationManager.addGpsStatusListener(new GpsStatus.Listener() {
                    @Override
                    public void onGpsStatusChanged(int event) {
                        if (event == GpsStatus.GPS_EVENT_SATELLITE_STATUS) {
                            GpsStatus st = locationManager.getGpsStatus(null);
                            int visible = 0, used = 0;
                            if (st != null) {
                                for (android.location.GpsSatellite s : st.getSatellites()) {
                                    visible++;
                                    if (s.usedInFix()) used++;
                                }
                            }
                            satVisible = visible;
                            satUsed = used;
                        }
                    }
                });
            }
        } catch (Exception e) {
            tvStatus.setText("卫星状态监听不可用：" + e.getClass().getSimpleName());
        }
    }

    // ---------- 0.5 秒刷新界面 ----------
    private final Runnable renderTask = new Runnable() {
        @Override
        public void run() {
            render();
            ui.postDelayed(this, REFRESH_MS);
        }
    };

    private void render() {
        Location loc = lastLocation;

        if (loc != null) {
            tvLat.setText(String.format(Locale.US, "纬度 %.6f°", loc.getLatitude()));
            tvLon.setText(String.format(Locale.US, "经度 %.6f°", loc.getLongitude()));

            double mps = lastSpeedMps;
            double kmh = mps * 3.6;
            tvSpeed.setText(String.format(Locale.US, "%.2f", kmh));
            tvSpeedUnit.setText(String.format(Locale.US, "km/h     ·     %.1f m/s", mps));

            if (loc.hasAccuracy()) {
                tvStatus.setText(String.format(Locale.US,
                        "定位精度 ±%.0f m · 数据每 0.5 秒刷新", loc.getAccuracy()));
            } else {
                tvStatus.setText("数据每 0.5 秒刷新");
            }
        } else {
            tvLat.setText("纬度 --.------");
            tvLon.setText("经度 ---.------");
            tvSpeed.setText("0.00");
            tvSpeedUnit.setText("km/h     ·     --.- m/s");
        }

        tvSatCount.setText(String.valueOf(satVisible));
        tvSatDetail.setText(String.format(Locale.US, "可见 %d · 参与定位 %d", satVisible, satUsed));
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(renderTask);
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacks(renderTask);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ui.removeCallbacks(renderTask);
        try {
            if (locationManager != null && locationListener != null) {
                locationManager.removeUpdates(locationListener);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && gnssCallback != null) {
                locationManager.unregisterGnssStatusCallback(gnssCallback);
            }
        } catch (Exception ignored) { }
    }
}